<?php

namespace frontend\assets;

use yii\web\AssetBundle;

/**
 * Main frontend application asset bundle.
 */
class AppAsset extends AssetBundle
{
    public $basePath = '@webroot';
    public $baseUrl = '@web';
    public $css = [
       "https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,700i&amp;subset=latin-ext,vietnamese",
   "https://fonts.googleapis.com/css?family=Pattaya&amp;subset=latin-ext,vietnamese",
    "https://fonts.googleapis.com/css?family=Roboto+Condensed:300,300i,400,400i,700,700i&amp;subset=latin-ext,vietnamese" ,
    "https://use.fontawesome.com/releases/v5.0.13/css/all.css" ,
    "https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css",
   
    "css/bootstrap.min.css",
    "css/animate.min.css",
    
   "css/assets/owl.carousel.min.css",
    "css/assets/owl.theme.default.min.css",
    
   
    "css/reset.css" ,
    "css/stellarnav.min.css",
    "css/slide.css",   
    "css/style.css",
    "css/modal.css",
    ];
    public $js = [
         "js/jquery.min.js",
        "js/owl.carousel.js",
        'js/stellarnav.min.js'
    ];
    public $depends = [
        'yii\web\YiiAsset',
        'yii\bootstrap\BootstrapAsset',
    ];

    public $jsOptions = [
        'position' => \yii\web\View::POS_HEAD
    ];
}
