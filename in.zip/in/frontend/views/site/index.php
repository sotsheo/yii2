<?php

/* @var $this yii\web\View */

$this->title = 'Home page';
?>
<div class="main">
        <!-- Gioi thieu -->
            <div class="introduce">
                    <div class="container">
                        <div class="title">
                        
                                <p>GIỚI THIỆU</p>
                                <p><img src="images/bdgt.png" ></p>
                            
                        </div>
                        <div class="row">
                            
                                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 wow fadeInLeft">
                                    <img src="images/gt.png" width="100%" height="362px">
                                </div>

                                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 wow fadeInRightBig">
                                    <div class="titles">CÔNG TYTNHH ĐẦU TƯ PHÁT TRIỂN MINH PHÚ THỊNH</div>
                                    <p><img src="images/mpt.png" width="42px" height="15px">nhận thiết kế và In offset phú khắp toàn quốc đã và đang mang tới cho khách hàng những dịch vụ in nhanh - giá rẻ -chất lượng cao.Với hệ thống cơ sở vật chất hiện đại ,cung với hệ thống gia công đồng bộ,đội ngũ nhân viên nhiệt tình -giau kinh nghiệm MPT khẳng định sẽ đáp ứng được nhu cầu của khách hàng về thiết kế bộ nhận diện ,ấn phẩm ,văn phòng ,án phẩm quảng cáo,bao bì -tem nhãn mác.... </p>
                                    <div class="titless">KỸ NĂNG CHUYÊN NGHIỆP</div>
                                    <div class="evaluate">
                                        <span>Chăm sóc khách hàng </span>
                                        <span>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            (có 2.687.538 lượt đánh giá)
                                        </span>
                                    </div>
                                    <div class="evaluate"><span>Chăm sóc khách hàng </span>
                                        <span>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            (có 2.687.538 lượt đánh giá)
                                        </span>
                                    </div>
                                    <div class="evaluate"><span>Chăm sóc khách hàng </span>
                                        <span>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            (có 2.687.538 lượt đánh giá)
                                        </span>
                                    </div>

                                </div>

                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                                    <div class="row row-43" >
                                        

                                            <?php if($introduce):?>
                                                <?php
                                                    foreach ($introduce as  $item):
                                                ?>
                                                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-12 wow fadeInUp">
                                                        <p><a href="#"><img src="<?php echo $item->image;?>"></a></p>
                                                        <p><?php echo number_format($item->number);?></p>
                                                        <p><?php echo $item->name;?></p>
                                                    </div>
                                                 <?php endforeach;?>
                                            <?php endif;?>
                                            
                                </div>

                            </div>
                        </div>
                    </div>
            </div>
        <!-- End gioi thieu -->

        <!-- Panner -->
            <div class="panner">
                <div class="container">
                    <div class="text-panner">
                        <h2>Chất lượng nhất -Hợp lý nhất -Nhanh nhất</h2>
                        <p>Tại Minh Phú Thịnh niềm tin được xây dựng bằng chất lượng ,chúng tôi cung cấp các giải pháp in và thiết kế tốt nhất cho thương hiệu khách hàng</p>
                        <a href="#">Liên hệ đặt dịch vụ</a>
                    </div>
                </div>
            </div>
        <!-- End panner -->

        <!-- Why service -->
            <div class="while">
                <div class="container">
                    <div class="title">
                    
                            <p>TẠI SAO CÁC BẠN CHỌN CHÚNG TÔI</p>
                            <p><img src="images/bd.png" style="max-width: 100%"></p>
                        
                    </div>
                    <div class="row row-43" >

                        
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 wow fadeInUp">
                            <p><a href="#"><img src="images/chatluong.png"></a></p>
                            <p>CHẤT LƯỢNG IN TỐT</p>
                            <p>Chúng tôi luôn luôn coi trọng chất lượng sản phẩm và đặt nó làm tiêu chí hàng đầu</p>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 wow fadeInUp">
                            <p><a href="#"><img src="images/gc.png"></a></p>
                            <p>GÍA CẢ PHÙ HỢP</p>
                            <p>Chúng tôi luôn luôn coi trọng chất lượng sản phẩm và đặt nó làm tiêu chí hàng đầu</p>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 wow fadeInUp">
                            <p><a href="#"><img src="images/cn.png"></a></p>
                            <p>CÔNG NGHỆ HIỆN ĐẠI</p>
                            <p>Chúng tôi luôn luôn coi trọng chất lượng sản phẩm và đặt nó làm tiêu chí hàng đầu</p>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 wow fadeInUp">
                            <p><a href="#"><img src="images/tb.png"></a></p>
                            <p>TIẾN BỘ</p>
                            <p>Chúng tôi luôn luôn coi trọng chất lượng sản phẩm và đặt nó làm tiêu chí hàng đầu</p>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 wow fadeInUp">
                            <p><a href="#"><img src="images/dv.png"></a></p>
                            <p>DỊCH VỤ KHÁCH HÀNG</p>
                            <p>Chúng tôi luôn luôn coi trọng chất lượng sản phẩm và đặt nó làm tiêu chí hàng đầu</p>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 wow fadeInUp">
                            <p><a href="#"><img src="images/gh.png"></a></p>
                            <p>GIAO HÀNG</p>
                            <p>Chúng tôi luôn luôn coi trọng chất lượng sản phẩm và đặt nó làm tiêu chí hàng đầu</p>
                        </div>


                    </div>
                </div>
            </div>
        <!-- End service -->

        <!-- Service -->
            <div class="service-product">
                <div class="container">
                
                    <div class="title">
                        <p>DỊCH VỤ SẢN PHẨM</p>
                        <p><img src="images/bdgt.png" ></p>
                    </div>

                    <div class="row">
                        <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 wow slideInRight">
                        <div class="title bg-orange">
                            <p>IN OFFSET</p>
                        </div>
                        <div class="list-data bg-orange">
                            <ul>
                                <li><a href="#"><img src="images/icon.png">In card visit</a></li>
                                <li><a href="#"><img src="images/icon.png">Phong bì</a></li>
                                <li><a href="#"><img src="images/icon.png">Tiểu đề thư </a></li>
                                <li><a href="#"><img src="images/icon.png">Kẹp file-folder</a></li>
                                <li><a href="#"><img src="images/icon.png">Catalogue-Brochure</a></li>
                                <li><a href="#"><img src="images/icon.png">Tờ rơi -tờ gấp</a></li>
                                <li><a href="#"><img src="images/icon.png">Sổ tay -sổ da</a></li>
                                <li><a href="#"><img src="images/icon.png">Bao đũa</a></li>
                                <li><a href="#"><img src="images/icon.png">Voucher-thẻ giảm giá</a></li>
                                <li><a href="#"><img src="images/icon.png">Hộp giấy</a></li>
                                <li><a href="#"><img src="images/icon.png">Poster</a></li>
                                <li><a href="#"><img src="images/icon.png">Menu-thực đơn</a></li>
                                <li><a href="#"><img src="images/icon.png">Nhãn đĩa</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 wow slideInRight">
                        <div class="title bg-blue">
                            <p>IN BAO BÌ-TEM NHÃN</p>
                        </div>
                        <div class="list-data bg-blue">
                            <ul>
                                <li><a href="#"><img src="images/icon.png">In card visit</a></li>
                                <li><a href="#"><img src="images/icon.png">Phong bì</a></li>
                                <li><a href="#"><img src="images/icon.png">Tiểu đề thư </a></li>
                                <li><a href="#"><img src="images/icon.png">Kẹp file-folder</a></li>
                                <li><a href="#"><img src="images/icon.png">Catalogue-Brochure</a></li>
                                <li><a href="#"><img src="images/icon.png">Tờ rơi -tờ gấp</a></li>
                                <li><a href="#"><img src="images/icon.png">Sổ tay -sổ da</a></li>
                                <li><a href="#"><img src="images/icon.png">Bao đũa</a></li>
                                <li><a href="#"><img src="images/icon.png">Voucher-thẻ giảm giá</a></li>
                                <li><a href="#"><img src="images/icon.png">Hộp giấy</a></li>
                                <li><a href="#"><img src="images/icon.png">Poster</a></li>
                                <li><a href="#"><img src="images/icon.png">Menu-thực đơn</a></li>
                                <li><a href="#"><img src="images/icon.png">Nhãn đĩa</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 wow slideInRight">
                        <div class="title bg-red">
                            <p>DỊCH VỤ KHÁC</p>
                        </div>
                        <div class="list-data bg-red">
                            <ul>
                                <li><a href="#"><img src="images/icon.png">In card visit</a></li>
                                <li><a href="#"><img src="images/icon.png">Phong bì</a></li>
                                <li><a href="#"><img src="images/icon.png">Tiểu đề thư </a></li>
                                <li><a href="#"><img src="images/icon.png">Kẹp file-folder</a></li>
                                <li><a href="#"><img src="images/icon.png">Catalogue-Brochure</a></li>
                                <li><a href="#"><img src="images/icon.png">Tờ rơi -tờ gấp</a></li>
                                <li><a href="#"><img src="images/icon.png">Sổ tay -sổ da</a></li>
                                <li><a href="#"><img src="images/icon.png">Bao đũa</a></li>
                                <li><a href="#"><img src="images/icon.png">Voucher-thẻ giảm giá</a></li>
                                <li><a href="#"><img src="images/icon.png">Hộp giấy</a></li>
                                <li><a href="#"><img src="images/icon.png">Poster</a></li>
                                <li><a href="#"><img src="images/icon.png">Menu-thực đơn</a></li>
                                <li><a href="#"><img src="images/icon.png">Nhãn đĩa</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 wow slideInRight">
                        <div class="title bg-blues">
                            <p>THIẾT KẾ</p>
                        </div>
                        <div class="list-data bg-blues">
                            <ul>
                                <li><a href="#"><img src="images/icon.png">In card visit</a></li>
                                <li><a href="#"><img src="images/icon.png">Phong bì</a></li>
                                <li><a href="#"><img src="images/icon.png">Tiểu đề thư </a></li>
                                <li><a href="#"><img src="images/icon.png">Kẹp file-folder</a></li>
                                <li><a href="#"><img src="images/icon.png">Catalogue-Brochure</a></li>
                                <li><a href="#"><img src="images/icon.png">Tờ rơi -tờ gấp</a></li>
                                <li><a href="#"><img src="images/icon.png">Sổ tay -sổ da</a></li>
                                <li><a href="#"><img src="images/icon.png">Bao đũa</a></li>
                                <li><a href="#"><img src="images/icon.png">Voucher-thẻ giảm giá</a></li>
                                <li><a href="#"><img src="images/icon.png">Hộp giấy</a></li>
                                <li><a href="#"><img src="images/icon.png">Poster</a></li>
                                <li><a href="#"><img src="images/icon.png">Menu-thực đơn</a></li>
                                <li><a href="#"><img src="images/icon.png">Nhãn đĩa</a></li>
                            </ul>
                        </div>
                    </div>

                </div>
                
                </div>
            </div>
        <!-- End service -->

         <!-- San pham tieu bieu --> 
            <div class="products-t">
                    <div class="container">
                        <div class="title">
                            <p>SẢN PHẨM TIÊU BIỂU CỦA CHÚNG TÔI</p>
                            <p><img src="images/bd.png" style="max-width: 100%"></p>
                            <p>Chúng tôi tự hào về chất lượng cũng như sự đa dạng của sản phẩm</p>
                        </div>
                    </div>
            
                <div class="title-product wow fadeInUp">
                    <hr>
                    <div class="container row-58">
                        <p class="title-2">IN BAO BÌ</p>
                        
                        <div class="container">
                  
                            <div class="row">
                                <div class="col-xl-12 col-lg-12 col-md-12">
                                    
                                
                                  <div class="owl-carousel owl-theme">

                                     <div class="item">
                                        <div class="product1">
                                            <div class="item-product">
                                               <div class="img-product">
                                                   <a href="#"><img src="images/item1.jpg" width="100%"></a>
                                                    <div class="clear"></div>
                                               </div>
                                               <div class="content-news">
                                                  <a href=""><h2>In kẹp file - folder</h2></a>
                                                  <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                  <div class="link-product">
                                                        <a href="">Xem chi tiết</a>
                                                </div>
                                               </div>
                                               
                                           </div>
                                        </div>
                                           
                                        <div class="product2">
                                            <div class="item-product">
                                               <div class="img-product">
                                                   <a href="#"><img src="images/item2.jpg" width="100%"></a>
                                                    <div class="clear"></div>
                                               </div>
                                               <div class="content-news">
                                                  <a href=""><h2>In kẹp file - folder</h2></a>
                                                  <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                  <div class="link-product">
                                                        <a href="">Xem chi tiết</a>
                                                </div>
                                               </div>
                                               
                                           </div>
                                        </div>

                                     </div>

                                      <div class="item">
                                        <div class="product1">
                                            <div class="item-product">
                                               <div class="img-product">
                                                   <a href="#"><img src="images/item3.jpg" width="100%"></a>
                                                    <div class="clear"></div>
                                               </div>
                                               <div class="content-news">
                                                  <a href=""><h2>In kẹp file - folder</h2></a>
                                                  <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                  <div class="link-product">
                                                        <a href="">Xem chi tiết</a>
                                                </div>
                                               </div>
                                               
                                           </div>
                                        </div>
                                           
                                        <div class="product2">
                                            <div class="item-product">
                                               <div class="img-product">
                                                   <a href="#"><img src="images/item4.jpg" width="100%"></a>
                                                    <div class="clear"></div>
                                               </div>
                                               <div class="content-news">
                                                  <a href=""><h2>In kẹp file - folder</h2></a>
                                                  <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                  <div class="link-product">
                                                        <a href="">Xem chi tiết</a>
                                                </div>
                                               </div>
                                               
                                           </div>
                                        </div>

                                     </div>

                                      <div class="item">
                                        <div class="product1">
                                            <div class="item-product">
                                               <div class="img-product">
                                                   <a href="#"><img src="images/item1.jpg" width="100%"></a>
                                                    <div class="clear"></div>
                                               </div>
                                               <div class="content-news">
                                                  <a href=""><h2>In kẹp file - folder</h2></a>
                                                  <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                  <div class="link-product">
                                                        <a href="">Xem chi tiết</a>
                                                </div>
                                               </div>
                                               
                                           </div>
                                        </div>
                                           
                                        <div class="product2">
                                            <div class="item-product">
                                               <div class="img-product">
                                                   <a href="#"><img src="images/item2.jpg" width="100%"></a>
                                                    <div class="clear"></div>
                                               </div>
                                               <div class="content-news">
                                                  <a href=""><h2>In kẹp file - folder</h2></a>
                                                  <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                  <div class="link-product">
                                                        <a href="">Xem chi tiết</a>
                                                </div>
                                               </div>
                                               
                                           </div>
                                        </div>

                                     </div>

                                      <div class="item">
                                        <div class="product1">
                                            <div class="item-product">
                                               <div class="img-product">
                                                   <a href="#"><img src="images/item3.jpg" width="100%"></a>
                                                    <div class="clear"></div>
                                               </div>
                                               <div class="content-news">
                                                  <a href=""><h2>In kẹp file - folder</h2></a>
                                                  <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                  <div class="link-product">
                                                        <a href="">Xem chi tiết</a>
                                                </div>
                                               </div>
                                               
                                           </div>
                                        </div>
                                           
                                        <div class="product2">
                                            <div class="item-product">
                                               <div class="img-product">
                                                   <a href="#"><img src="images/item4.jpg" width="100%"></a>
                                                    <div class="clear"></div>
                                               </div>
                                               <div class="content-news">
                                                  <a href=""><h2>In kẹp file - folder</h2></a>
                                                  <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                  <div class="link-product">
                                                        <a href="">Xem chi tiết</a>
                                                </div>
                                               </div>
                                               
                                           </div>
                                        </div>

                                     </div>

                                      <div class="item">
                                        <div class="product1">
                                            <div class="item-product">
                                               <div class="img-product">
                                                   <a href="#"><img src="images/item1.jpg" width="100%"></a>
                                                    <div class="clear"></div>
                                               </div>
                                               <div class="content-news">
                                                  <a href=""><h2>In kẹp file - folder</h2></a>
                                                  <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                  <div class="link-product">
                                                        <a href="">Xem chi tiết</a>
                                                </div>
                                               </div>
                                               
                                           </div>
                                        </div>
                                           
                                        <div class="product2">
                                            <div class="item-product">
                                               <div class="img-product">
                                                   <a href="#"><img src="images/item2.jpg" width="100%"></a>
                                                    <div class="clear"></div>
                                               </div>
                                               <div class="content-news">
                                                  <a href=""><h2>In kẹp file - folder</h2></a>
                                                  <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                  <div class="link-product">
                                                        <a href="">Xem chi tiết</a>
                                                </div>
                                               </div>
                                               
                                           </div>
                                        </div>

                                     </div>

                                      <div class="item">
                                        <div class="product1">
                                            <div class="item-product">
                                               <div class="img-product">
                                                   <a href="#"><img src="images/item3.jpg" width="100%"></a>
                                                    <div class="clear"></div>
                                               </div>
                                               <div class="content-news">
                                                  <a href=""><h2>In kẹp file - folder</h2></a>
                                                  <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                  <div class="link-product">
                                                        <a href="">Xem chi tiết</a>
                                                </div>
                                               </div>
                                               
                                           </div>
                                        </div>
                                           
                                        <div class="product2">
                                            <div class="item-product">
                                               <div class="img-product">
                                                   <a href="#"><img src="images/item4.jpg" width="100%"></a>
                                                    <div class="clear"></div>

                                               </div>
                                               <div class="content-news">
                                                  <a href=""><h2>In kẹp file - folder</h2></a>
                                                  <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                  <div class="link-product">
                                                        <a href="">Xem chi tiết</a>
                                                </div>
                                               </div>
                                               
                                           </div>
                                        </div>

                                     </div>
                                   
                                  </div>
                              </div>  
                            </div>
                    
                            <script type="text/javascript">
                              $('.owl-carousel').owlCarousel({
                                loop:true,
                                margin:10,
                                nav:true,
                                responsive:{
                                     0:{
                                                items:1
                                            },
                                           576:{
                                                items:2
                                            },
                                            767:{
                                                items:3
                                            },
                                            1000:{
                                                items:4
                                            }
                                }
                            })
                            </script>
                        </div>  
                    </div>
                </div>
            
                
                <div class="title-product wow fadeInUp">
                    <hr>
                    <div class="container row-58">
                        <p class="title-2">IN BAO BÌ</p>
                        
                        <div class="container">
                  
                            <div class="row">
                                <div class="col-xl-12 col-lg-12 col-md-12">
                                    
                                
                                  <div class="owl-carousel owl-theme">

                                     <div class="item">
                                        <div class="product1">
                                            <div class="item-product">
                                               <div class="img-product">
                                                   <a href="#"><img src="images/item1.jpg" width="100%"></a>
                                                    <div class="clear"></div>
                                               </div>
                                               <div class="content-news">
                                                  <a href=""><h2>In kẹp file - folder</h2></a>
                                                  <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                  <div class="link-product">
                                                        <a href="">Xem chi tiết</a>
                                                </div>
                                               </div>
                                               
                                           </div>
                                        </div>
                                           
                                        <div class="product2">
                                            <div class="item-product">
                                               <div class="img-product">
                                                   <a href="#"><img src="images/item2.jpg" width="100%"></a>
                                                    <div class="clear"></div>
                                               </div>
                                               <div class="content-news">
                                                  <a href=""><h2>In kẹp file - folder</h2></a>
                                                  <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                  <div class="link-product">
                                                        <a href="">Xem chi tiết</a>
                                                </div>
                                               </div>
                                               
                                           </div>
                                        </div>

                                     </div>

                                      <div class="item">
                                        <div class="product1">
                                            <div class="item-product">
                                               <div class="img-product">
                                                   <a href="#"><img src="images/item3.jpg" width="100%"></a>
                                                    <div class="clear"></div>
                                               </div>
                                               <div class="content-news">
                                                  <a href=""><h2>In kẹp file - folder</h2></a>
                                                  <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                  <div class="link-product">
                                                        <a href="">Xem chi tiết</a>
                                                </div>
                                               </div>
                                               
                                           </div>
                                        </div>
                                           
                                        <div class="product2">
                                            <div class="item-product">
                                               <div class="img-product">
                                                   <a href="#"><img src="images/item4.jpg" width="100%"></a>
                                                    <div class="clear"></div>
                                               </div>
                                               <div class="content-news">
                                                  <a href=""><h2>In kẹp file - folder</h2></a>
                                                  <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                  <div class="link-product">
                                                        <a href="">Xem chi tiết</a>
                                                </div>
                                               </div>
                                               
                                           </div>
                                        </div>

                                     </div>

                                      <div class="item">
                                        <div class="product1">
                                            <div class="item-product">
                                               <div class="img-product">
                                                   <a href="#"><img src="images/item1.jpg" width="100%"></a>
                                                    <div class="clear"></div>
                                               </div>
                                               <div class="content-news">
                                                  <a href=""><h2>In kẹp file - folder</h2></a>
                                                  <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                  <div class="link-product">
                                                        <a href="">Xem chi tiết</a>
                                                </div>
                                               </div>
                                               
                                           </div>
                                        </div>
                                           
                                        <div class="product2">
                                            <div class="item-product">
                                               <div class="img-product">
                                                   <a href="#"><img src="images/item2.jpg" width="100%"></a>
                                                    <div class="clear"></div>
                                               </div>
                                               <div class="content-news">
                                                  <a href=""><h2>In kẹp file - folder</h2></a>
                                                  <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                  <div class="link-product">
                                                        <a href="">Xem chi tiết</a>
                                                </div>
                                               </div>
                                               
                                           </div>
                                        </div>

                                     </div>

                                      <div class="item">
                                        <div class="product1">
                                            <div class="item-product">
                                               <div class="img-product">
                                                   <a href="#"><img src="images/item3.jpg" width="100%"></a>
                                                    <div class="clear"></div>
                                               </div>
                                               <div class="content-news">
                                                  <a href=""><h2>In kẹp file - folder</h2></a>
                                                  <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                  <div class="link-product">
                                                        <a href="">Xem chi tiết</a>
                                                </div>
                                               </div>
                                               
                                           </div>
                                        </div>
                                           
                                        <div class="product2">
                                            <div class="item-product">
                                               <div class="img-product">
                                                   <a href="#"><img src="images/item4.jpg" width="100%"></a>
                                                    <div class="clear"></div>
                                               </div>
                                               <div class="content-news">
                                                  <a href=""><h2>In kẹp file - folder</h2></a>
                                                  <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                  <div class="link-product">
                                                        <a href="">Xem chi tiết</a>
                                                </div>
                                               </div>
                                               
                                           </div>
                                        </div>

                                     </div>

                                      <div class="item">
                                        <div class="product1">
                                            <div class="item-product">
                                               <div class="img-product">
                                                   <a href="#"><img src="images/item1.jpg" width="100%"></a>
                                                    <div class="clear"></div>
                                               </div>
                                               <div class="content-news">
                                                  <a href=""><h2>In kẹp file - folder</h2></a>
                                                  <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                  <div class="link-product">
                                                        <a href="">Xem chi tiết</a>
                                                </div>
                                               </div>
                                               
                                           </div>
                                        </div>
                                           
                                        <div class="product2">
                                            <div class="item-product">
                                               <div class="img-product">
                                                   <a href="#"><img src="images/item2.jpg" width="100%"></a>
                                                    <div class="clear"></div>
                                               </div>
                                               <div class="content-news">
                                                  <a href=""><h2>In kẹp file - folder</h2></a>
                                                  <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                  <div class="link-product">
                                                        <a href="">Xem chi tiết</a>
                                                </div>
                                               </div>
                                               
                                           </div>
                                        </div>

                                     </div>

                                      <div class="item">
                                        <div class="product1">
                                            <div class="item-product">
                                               <div class="img-product">
                                                   <a href="#"><img src="images/item3.jpg" width="100%"></a>
                                                    <div class="clear"></div>
                                               </div>
                                               <div class="content-news">
                                                  <a href=""><h2>In kẹp file - folder</h2></a>
                                                  <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                  <div class="link-product">
                                                        <a href="">Xem chi tiết</a>
                                                </div>
                                               </div>
                                               
                                           </div>
                                        </div>
                                           
                                        <div class="product2">
                                            <div class="item-product">
                                               <div class="img-product">
                                                   <a href="#"><img src="images/item4.jpg" width="100%"></a>
                                                    <div class="clear"></div>

                                               </div>
                                               <div class="content-news">
                                                  <a href=""><h2>In kẹp file - folder</h2></a>
                                                  <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                  <div class="link-product">
                                                        <a href="">Xem chi tiết</a>
                                                </div>
                                               </div>
                                               
                                           </div>
                                        </div>

                                     </div>
                                   
                                  </div>
                              </div>  
                            </div>
                    
                            <script type="text/javascript">
                              $('.owl-carousel').owlCarousel({
                                loop:true,
                                margin:10,
                                nav:true,
                                responsive:{
                                     0:{
                                                items:1
                                            },
                                           576:{
                                                items:2
                                            },
                                            767:{
                                                items:3
                                            },
                                            1000:{
                                                items:4
                                            }
                                }
                            })
                            </script>
                        </div>  
                    </div>
                </div>

                <div class="title-product wow fadeInUp">
                    <hr>
                    <div class="container row-58">
                        <p class="title-2">IN ITEM NHÃN MÁC</p>
                        
                        <div class="container">
                  
                                <div class="row">
                                    <div class="col-xl-12 col-lg-12 col-md-12">
                                        
                                    
                                      <div class="owl-carousel owl-theme">

                                         <div class="item">
                                            <div class="product1">
                                                <div class="item-product">
                                                   <div class="img-product">
                                                       <a href="#"><img src="images/item1.jpg" width="100%"></a>
                                                        <div class="clear"></div>
                                                   </div>
                                                   <div class="content-news">
                                                      <a href=""><h2>In kẹp file - folder</h2></a>
                                                      <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                      <div class="link-product">
                                                            <a href="">Xem chi tiết</a>
                                                    </div>
                                                   </div>
                                                   
                                               </div>
                                            </div>
                                               
                                            <div class="product2">
                                                <div class="item-product">
                                                   <div class="img-product">
                                                       <a href="#"><img src="images/item2.jpg" width="100%"></a>
                                                        <div class="clear"></div>
                                                   </div>
                                                   <div class="content-news">
                                                      <a href=""><h2>In kẹp file - folder</h2></a>
                                                      <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                      <div class="link-product">
                                                            <a href="">Xem chi tiết</a>
                                                    </div>
                                                   </div>
                                                   
                                               </div>
                                            </div>

                                         </div>

                                          <div class="item">
                                            <div class="product1">
                                                <div class="item-product">
                                                   <div class="img-product">
                                                       <a href="#"><img src="images/item3.jpg" width="100%"></a>
                                                        <div class="clear"></div>
                                                   </div>
                                                   <div class="content-news">
                                                      <a href=""><h2>In kẹp file - folder</h2></a>
                                                      <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                      <div class="link-product">
                                                            <a href="">Xem chi tiết</a>
                                                    </div>
                                                   </div>
                                                   
                                               </div>
                                            </div>
                                               
                                            <div class="product2">
                                                <div class="item-product">
                                                   <div class="img-product">
                                                       <a href="#"><img src="images/item4.jpg" width="100%"></a>
                                                        <div class="clear"></div>
                                                   </div>
                                                   <div class="content-news">
                                                      <a href=""><h2>In kẹp file - folder</h2></a>
                                                      <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                      <div class="link-product">
                                                            <a href="">Xem chi tiết</a>
                                                    </div>
                                                   </div>
                                                   
                                               </div>
                                            </div>

                                         </div>

                                          <div class="item">
                                            <div class="product1">
                                                <div class="item-product">
                                                   <div class="img-product">
                                                       <a href="#"><img src="images/item1.jpg" width="100%"></a>
                                                        <div class="clear"></div>
                                                   </div>
                                                   <div class="content-news">
                                                      <a href=""><h2>In kẹp file - folder</h2></a>
                                                      <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                      <div class="link-product">
                                                            <a href="">Xem chi tiết</a>
                                                    </div>
                                                   </div>
                                                   
                                               </div>
                                            </div>
                                               
                                            <div class="product2">
                                                <div class="item-product">
                                                   <div class="img-product">
                                                       <a href="#"><img src="images/item2.jpg" width="100%"></a>
                                                       <div class="clear"></div>
                                                   </div>
                                                   <div class="content-news">
                                                      <a href=""><h2>In kẹp file - folder</h2></a>
                                                      <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                      <div class="link-product">
                                                            <a href="">Xem chi tiết</a>
                                                    </div>
                                                   </div>
                                                   
                                               </div>
                                            </div>

                                         </div>

                                          <div class="item">
                                            <div class="product1">
                                                <div class="item-product">
                                                   <div class="img-product">
                                                       <a href="#"><img src="images/item3.jpg" width="100%"></a>
                                                        <div class="clear"></div>
                                                   </div>
                                                   <div class="content-news">
                                                      <a href=""><h2>In kẹp file - folder</h2></a>
                                                      <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                      <div class="link-product">
                                                            <a href="">Xem chi tiết</a>
                                                    </div>
                                                   </div>
                                                   
                                               </div>
                                            </div>
                                               
                                            <div class="product2">
                                                <div class="item-product">
                                                   <div class="img-product">
                                                       <a href="#"><img src="images/item4.jpg" width="100%"></a>
                                                        <div class="clear"></div>
                                                   </div>
                                                   <div class="content-news">
                                                      <a href=""><h2>In kẹp file - folder</h2></a>
                                                      <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                      <div class="link-product">
                                                            <a href="">Xem chi tiết</a>
                                                    </div>
                                                   </div>
                                                   
                                               </div>
                                            </div>

                                         </div>

                                          <div class="item">
                                            <div class="product1">
                                                <div class="item-product">
                                                   <div class="img-product">
                                                       <a href="#"><img src="images/item1.jpg" width="100%"></a>
                                                        <div class="clear"></div>
                                                   </div>
                                                   <div class="content-news">
                                                      <a href=""><h2>In kẹp file - folder</h2></a>
                                                      <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                      <div class="link-product">
                                                            <a href="">Xem chi tiết</a>
                                                    </div>
                                                   </div>
                                                   
                                               </div>
                                            </div>
                                               
                                            <div class="product2">
                                                <div class="item-product">
                                                   <div class="img-product">
                                                       <a href="#"><img src="images/item2.jpg" width="100%"></a>
                                                        <div class="clear"></div>
                                                   </div>
                                                   <div class="content-news">
                                                      <a href=""><h2>In kẹp file - folder</h2></a>
                                                      <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                      <div class="link-product">
                                                            <a href="">Xem chi tiết</a>
                                                    </div>
                                                   </div>
                                                   
                                               </div>
                                            </div>

                                         </div>

                                          <div class="item">
                                            <div class="product1">
                                                <div class="item-product">
                                                   <div class="img-product">
                                                       <a href="#"><img src="images/item3.jpg" width="100%"></a>
                                                        <div class="clear"></div>
                                                   </div>
                                                   <div class="content-news">
                                                      <a href=""><h2>In kẹp file - folder</h2></a>
                                                      <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                      <div class="link-product">
                                                            <a href="">Xem chi tiết</a>
                                                    </div>
                                                   </div>
                                                   
                                               </div>
                                            </div>
                                               
                                            <div class="product2">
                                                <div class="item-product">
                                                   <div class="img-product">
                                                       <a href="#"><img src="images/item4.jpg" width="100%"></a>
                                                        <div class="clear"></div>
                                                   </div>
                                                   <div class="content-news">
                                                      <a href=""><h2>In kẹp file - folder</h2></a>
                                                      <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                      <div class="link-product">
                                                            <a href="">Xem chi tiết</a>
                                                    </div>
                                                   </div>
                                                   
                                               </div>
                                            </div>

                                         </div>
                                       
                                      </div>
                                  </div>
                                 
                              
                                </div>
                        
                                <script type="text/javascript">
                                  $('.owl-carousel').owlCarousel({
                                    loop:true,
                                    margin:10,
                                    nav:true,
                                    responsive:{
                                         0:{
                                                items:1
                                            },
                                           576:{
                                                items:2
                                            },
                                            767:{
                                                items:3
                                            },
                                            1000:{
                                                items:4
                                            }
                                    }
                                })
                                </script>
                        </div>  
                    </div>
                </div>


                <div class="title-product last wow fadeInUp">
                    <hr>
                    <div class="container row-58">
                        <p class="title-2">IN BIỂU MẪU</p>
                        
                        <div class="container">
                  
                                <div class="row">
                                    <div class="col-xl-12 col-lg-12 col-md-12">
                                        
                                    
                                      <div class="owl-carousel owl-theme">

                                         <div class="item">
                                            <div class="product1">
                                                <div class="item-product">
                                                   <div class="img-product">
                                                       <a href="#"><img src="images/item1.jpg" width="100%"></a>
                                                         <div class="clear"></div>
                                                   </div>
                                                   <div class="content-news">
                                                      <a href=""><h2>In kẹp file - folder</h2></a>
                                                      <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                      <div class="link-product">
                                                            <a href="">Xem chi tiết</a>
                                                    </div>
                                                   </div>
                                                   
                                               </div>
                                            </div>
                                               
                                            <div class="product2">
                                                <div class="item-product">
                                                   <div class="img-product">
                                                       <a href="#"><img src="images/item1.jpg" width="100%"></a>
                                                         <div class="clear"></div>
                                                   </div>
                                                   <div class="content-news">
                                                      <a href=""><h2>In kẹp file - folder</h2></a>
                                                      <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                      <div class="link-product">
                                                            <a href="">Xem chi tiết</a>
                                                    </div>
                                                   </div>
                                                   
                                               </div>
                                            </div>

                                         </div>

                                          <div class="item">
                                            <div class="product1">
                                                <div class="item-product">
                                                   <div class="img-product">
                                                       <a href="#"><img src="images/item1.jpg" width="100%"></a>
                                                         <div class="clear"></div>
                                                   </div>
                                                   <div class="content-news">
                                                      <a href=""><h2>In kẹp file - folder</h2></a>
                                                      <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                      <div class="link-product">
                                                            <a href="">Xem chi tiết</a>
                                                    </div>
                                                   </div>
                                                   
                                               </div>
                                            </div>
                                               
                                            <div class="product2">
                                                <div class="item-product">
                                                   <div class="img-product">
                                                       <a href="#"><img src="images/item1.jpg" width="100%"></a>
                                                        <div class="clear"></div>
                                                   </div>
                                                   <div class="content-news">
                                                      <a href=""><h2>In kẹp file - folder</h2></a>
                                                      <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                      <div class="link-product">
                                                            <a href="">Xem chi tiết</a>
                                                    </div>
                                                   </div>
                                                   
                                               </div>
                                            </div>

                                         </div>

                                          <div class="item">
                                            <div class="product1">
                                                <div class="item-product">
                                                   <div class="img-product">
                                                       <a href="#"><img src="images/item1.jpg" width="100%"></a>
                                                         <div class="clear"></div>
                                                   </div>
                                                   <div class="content-news">
                                                      <a href=""><h2>In kẹp file - folder</h2></a>
                                                      <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                      <div class="link-product">
                                                            <a href="">Xem chi tiết</a>
                                                    </div>
                                                   </div>
                                                   
                                               </div>
                                            </div>
                                               
                                            <div class="product2">
                                                <div class="item-product">
                                                   <div class="img-product">
                                                       <a href="#"><img src="images/item1.jpg" width="100%"></a>
                                                         <div class="clear"></div>
                                                   </div>
                                                   <div class="content-news">
                                                      <a href=""><h2>In kẹp file - folder</h2></a>
                                                      <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                      <div class="link-product">
                                                            <a href="">Xem chi tiết</a>
                                                    </div>
                                                   </div>
                                                   
                                               </div>
                                            </div>

                                         </div>

                                          <div class="item">
                                            <div class="product1">
                                                <div class="item-product">
                                                   <div class="img-product">
                                                       <a href="#"><img src="images/item1.jpg" width="100%"></a>
                                                         <div class="clear"></div>
                                                   </div>
                                                   <div class="content-news">
                                                      <a href=""><h2>In kẹp file - folder</h2></a>
                                                      <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                      <div class="link-product">
                                                            <a href="">Xem chi tiết</a>
                                                    </div>
                                                   </div>
                                                   
                                               </div>
                                            </div>
                                               
                                            <div class="product2">
                                                <div class="item-product">
                                                   <div class="img-product">
                                                       <a href="#"><img src="images/item1.jpg" width="100%"></a>
                                                         <div class="clear"></div>
                                                   </div>
                                                   <div class="content-news">
                                                      <a href=""><h2>In kẹp file - folder</h2></a>
                                                      <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                      <div class="link-product">
                                                            <a href="">Xem chi tiết</a>
                                                    </div>
                                                   </div>
                                                   
                                               </div>
                                            </div>

                                         </div>

                                          <div class="item">
                                            <div class="product1">
                                                <div class="item-product">
                                                   <div class="img-product">
                                                       <a href="#"><img src="images/item1.jpg" width="100%"></a>
                                                         <div class="clear"></div>
                                                   </div>
                                                   <div class="content-news">
                                                      <a href=""><h2>In kẹp file - folder</h2></a>
                                                      <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                      <div class="link-product">
                                                            <a href="">Xem chi tiết</a>
                                                    </div>
                                                   </div>
                                                   
                                               </div>
                                            </div>
                                               
                                            <div class="product2">
                                                <div class="item-product">
                                                   <div class="img-product">
                                                       <a href="#"><img src="images/item1.jpg" width="100%"></a>
                                                         <div class="clear"></div>
                                                   </div>
                                                   <div class="content-news">
                                                      <a href=""><h2>In kẹp file - folder</h2></a>
                                                      <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                      <div class="link-product">
                                                            <a href="">Xem chi tiết</a>
                                                    </div>
                                                   </div>
                                                   
                                               </div>
                                            </div>

                                         </div>

                                          <div class="item">
                                            <div class="product1">
                                                <div class="item-product">
                                                   <div class="img-product">
                                                       <a href="#"><img src="images/item1.jpg" width="100%"></a>
                                                         <div style="clear: both;"></div>
                                                   </div>
                                                   <div class="content-news">
                                                      <a href=""><h2>In kẹp file - folder</h2></a>
                                                      <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                      <div class="link-product">
                                                            <a href="">Xem chi tiết</a>
                                                    </div>
                                                   </div>
                                                   
                                               </div>
                                            </div>
                                               
                                            <div class="product2">
                                                <div class="item-product">
                                                   <div class="img-product">
                                                       <a href="#"><img src="images/item1.jpg" width="100%"></a>
                                                         <div style="clear: both;"></div>
                                                   </div>
                                                   <div class="content-news">
                                                      <a href=""><h2>In kẹp file - folder</h2></a>
                                                      <p>In kẹp file giá rẻ tại Thanh Xuân,Hà Nội</p>
                                                      <div class="link-product">
                                                            <a href="">Xem chi tiết</a>
                                                    </div>
                                                   </div>
                                                   
                                               </div>
                                            </div>

                                         </div>
                                       
                                      </div>
                                  </div>
                                 
                              
                                </div>
                        
                                <script type="text/javascript">
                                  $('.owl-carousel').owlCarousel({
                                    loop:true,
                                    margin:10,
                                    nav:true,
                                    responsive:{
                                         0:{
                                                items:1
                                            },
                                           576:{
                                                items:2
                                            },
                                            767:{
                                                items:3
                                            },
                                            1000:{
                                                items:4
                                            }
                                    }
                                })
                                </script>
                        </div>  
                    </div>
                </div>
            </div>

        <!--end San pham tb -->

        <!-- Paner dv -->
            <div class="paner-service">
                <div class="container">
                    <div class="row">

                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 wow rotateInUpLeft">
                            <div class="title-service">
                                <p>ĐẶT DỊCH VỤ</p>
                                <p><img src="images/bdgt.png" ></p>
                            </div>
                            <div class="content-service">
                                <p>Quý khách có nhu cầu thiết kế hoặc đặt item ,nhãn,decal,vui lòng hoàn thành form bên cạnh hoặc gọi tới hotline:<b>090.225.4648</b> để được tư vấn tốt nhất</p>
                                <p>Với phương châm *thiết kế đẹp-in nhanh -giá cạnh tranh * Minh Phú Thịnh luôn nỗ lực hết mình để đem lại những sản phẩm tốt nhất để tới tay khách hàng</p>
                                <p>Rất mong được hợp tác cùng quý khách</p>
                            </div>
                        </div>

                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 wow rotateInUpLeft">
                        
                            <div class="form">
                                <form>
                                    <input type="text" name="name" placeholder="Tên của bạn">
                                    <input type="text" name="phone" placeholder="Số điện thoại">
                                    <input type="email" name="email" placeholder="Email">
                                    <select>
                                        <option>Chọn dịch vụ</option>
                                    </select>
                                    <textarea placeholder="Nội dung"></textarea>
                                    <input type="submit" name="submit" value="Gửi yêu cầu">
                                </form>
                                

                            </div>
                        </div>

                    </div>
                </div>
            </div>
        
        <!-- End paner dv -->
    
        <!-- Tin tuc cap nhat -->
            <div class="updated-n">
                    <div class="title-ud">
                        <p>TIN TỨC CẬP NHẬT</p>
                        <p><img src="images/bdgt.png" ></p>
                    </div>
                        <div class="container">
                      
                            <div class="row">
                                <div class="col-xl-12 col-lg-12 col-md-12">
                                    
                                
                                    <div class="owl-carousel owl-theme">
                                        <div class="item">
                                           <div class="item-news">
                                               <div class="img">
                                                   <a href="#"><img src="images/product.jpg" width="100%"></a>
                                                     <div class="clear"></div>
                                               </div>
                                               <div class="content-news">
                                                    <a href=""><p class="name-news"> 11 KỸ THUẬT IN CHUYÊN NGHIỆP ĐƯỢC CẬP NHẬT TRONG ...</p></a>
                                                   <hr>
                                                   <p><span><i class="fa fa-clock"></i>11/14/2017</span><span>|</span><span><i class="fa fa-user"></i>Đăng bởi:Admin</span></p>
                                               </div>
                                           </div>
                                        </div>

                                        <div class="item">
                                            <div class="item-news">
                                               <div class="img">
                                                   <a href="#"><img src="images/product.jpg" width="100%"></a>
                                                     <div class="clear"></div>
                                               </div>
                                               <div class="content-news">
                                                   <a href=""><p class="name-news"> 11 KỸ THUẬT IN CHUYÊN NGHIỆP ĐƯỢC CẬP NHẬT TRONG ...</p></a>
                                                    <hr>
                                                  <p><span><i class="fa fa-clock"></i>11/14/2017</span><span>|</span><span><i class="fa fa-user"></i>Đăng bởi:Admin</span></p>
                                               </div>
                                            </div>
                                        </div>

                                        <div class="item">
                                            <div class="item-news">
                                               <div class="img">
                                                   <a href="#"><img src="images/product.jpg" width="100%"></a>
                                                     <div class="clear"></div>
                                               </div>
                                               <div class="content-news">
                                                    <a href=""><p class="name-news"> 11 KỸ THUẬT IN CHUYÊN NGHIỆP ĐƯỢC CẬP NHẬT TRONG ...</p></a>
                                                    <hr>
                                                  <p><span><i class="fa fa-clock"></i>11/14/2017</span><span>|</span><span><i class="fa fa-user"></i>Đăng bởi:Admin</span></p>
                                               </div>
                                            </div>
                                        </div>

                                        <div class="item">
                                            <div class="item-news">
                                               <div class="img">
                                                   <a href="#"><img src="images/product.jpg" width="100%"></a>
                                                     <div class="clear"></div>
                                               </div>
                                               <div class="content-news">
                                                   <a href=""><p class="name-news">11 KỸ THUẬT IN CHUYÊN NGHIỆP ĐƯỢC CẬP NHẬT TRONG ...</p></a>
                                                  <hr>
                                                   <p><span><i class="fa fa-clock"></i> 11/14/2017</span><span>|</span><span><i class="fa fa-user"></i>Đăng bởi:Admin</span></p>
                                               </div>
                                           </div>
                                        </div>

                                        <div class="item">
                                            <div class="item-news">
                                               <div class="img">
                                                   <a href="#"><img src="images/product.jpg" width="100%"></a>
                                                     <div class="clear"></div>
                                               </div>
                                               <div class="content-news">
                                                  <a href=""><p class="name-news">11 KỸ THUẬT IN CHUYÊN NGHIỆP ĐƯỢC CẬP NHẬT TRONG ...</p></a>
                                                    <hr>
                                                   <p><span><i class="fa fa-clock"></i> 11/14/2017</span><span>|</span><span><i class="fa fa-user"></i>Đăng bởi:Admin</span></p>
                                               </div>
                                            </div>
                                        </div>

                                        <div class="item">
                                      
                                           <div class="item-news">
                                               <div class="img">
                                                   <a href="#"><img src="images/product.jpg" width="100%"></a>
                                                     <div class="clear"></div>
                                               </div>
                                               <div class="content-news">
                                                    <a href=""><p class="name-news">11 KỸ THUẬT IN CHUYÊN NGHIỆP ĐƯỢC CẬP NHẬT TRONG ...</p></a>
                                                   <hr>
                                                   <p><span><i class="fa fa-clock"></i> 11/14/2017</span><span>|</span><span><i class="fa fa-user"></i>Đăng bởi:Admin</span></p>
                                               </div>
                                           </div>
                                        </div>

                                    </div>
                                </div>
                    
                            <script type="text/javascript">
                              $('.owl-carousel').owlCarousel({
                                loop:true,
                                margin:10,
                                nav:true,
                                responsive:{
                                    0:{
                                                        items:1
                                                    },
                                                   576:{
                                                        items:2
                                                    },
                                                    767:{
                                                        items:3
                                                    },
                                                    1000:{
                                                        items:4
                                                    }
                                }
                            })
                            </script>
                            </div>
                        </div>
            </div>
            
        <!-- Lh -->
            <div class="contact">

                    <div class="title-ud">
                        <p>TIN TỨC ONLINE</p>
                        <p><img src="images/bdgt.png" ></p>
                    </div>
                    <div class="container">
                        <div class="row">


                            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 wow bounce">
                                <div class="img-contact">
                                    <a href=""><img src="images/lh1.jpg" width="100%"></a>
                                      <div class="clear"></div>
                                </div>
                                <div class="name-contact">
                                    <a href=""><p>NGUYỄN VIỆT HƯNG</p></a>
                                    <p>Nhân viên chăm sóc khách hàng</p>
                                </div>
                                <div class="content-contact">
                                    <p><img src="images/icon1.png">024.62591.561 -090.225.4648</p>
                                    <p><img src="images/icon2.png">In minhphuthinh</p>
                                    <p><img src="images/icon3.png">024.62591.561 -090.225.4648</p>
                                    <p><span><img src="images/icon4.png"></span><span>Inminhphuthinh@gmail.com</span></p>
                                </div>
                                
                                    <p> <a href="">Liên hệ</a></p>
                                
                            </div>

                            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 wow bounce">
                                <div class="img-contact">
                                    <a href=""><img src="images/lh1.jpg" width="100%"></a>
                                      <div class="clear"></div>
                                </div>
                                <div class="name-contact">
                                    <a href=""><p>NGUYỄN VIỆT HƯNG</p></a>
                                    <p>Nhân viên chăm sóc khách hàng</p>
                                </div>
                                <div class="content-contact">
                                    <p><img src="images/icon1.png">024.62591.561 -090.225.4648</p>
                                    <p><img src="images/icon2.png">In minhphuthinh</p>
                                    <p><img src="images/icon3.png">024.62591.561 -090.225.4648</p>
                                    <p><img src="images/icon4.png">Inminhphuthinh@gmail.com</p>
                                </div>
                                
                                    <p> <a href="">Liên hệ</a></p>
                                
                            </div>

                            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 wow bounce">
                                <div class="img-contact">
                                    <a href=""><img src="images/lh1.jpg" width="100%"></a>
                                      <div class="clear"></div>
                                </div>
                                <div class="name-contact">
                                    <a href=""><p>NGUYỄN VIỆT HƯNG</p></a>
                                    <p>Nhân viên chăm sóc khách hàng</p>
                                </div>
                                <div class="content-contact">
                                    <p><img src="images/icon1.png"><span>024.62591.561 -090.225.4648</p>
                                    <p><img src="images/icon2.png"><span>In minhphuthinh</p>
                                    <p><img src="images/icon3.png"><span>024.62591.561 -090.225.4648</p>
                                    <p><img src="images/icon4.png"><span>Inminhphuthinh@gmail.com</p>
                                </div>
                                
                                    <p> <a href="">Liên hệ</a></p>
                                
                            </div>

                            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 wow bounce">
                                <div class="img-contact">
                                    <a href=""><img src="images/lh1.jpg" width="100%"></a>
                                      <div class="clear"></div>
                                </div>
                                <div class="name-contact">
                                    <a href=""><p>NGUYỄN VIỆT HƯNG</p></a>
                                    <p>Nhân viên chăm sóc khách hàng</p>
                                </div>
                                <div class="content-contact">
                                    <p><img src="images/icon1.png">024.62591.561 -090.225.4648</p>
                                    <p><img src="images/icon2.png">In minhphuthinh</p>
                                    <p><img src="images/icon3.png">024.62591.561 -090.225.4648</p>
                                    <p><img src="images/icon4.png">Inminhphuthinh@gmail.com</p>
                                </div>
                                
                                    <p> <a href="">Liên hệ</a></p>
                                
                            </div>

                        </div>
                    </div>
                    
            </div>

            <div class="customer">
                    <div class="title-ud news">
                        <p>
                            KHÁCH HÀNG TIÊU BIỂU
                        </p>
                        <p><img src="images/bdgt.png" ></p>
                        <p>Các khách hàng đã tin tưởng vào dịch vụ của chúng tôi</p>
                    </div>
                    <div class="container">
                  
                                <div class="row">
                                    <div class="col-xl-12 col-lg-12 col-md-12 wow fadeInLeft">
                                        
                                    
                                        <div class="owl-carousel owl-theme">
                                            <div class="item">
                                              <a href=""> <img src="images/bh1.png"></a>
                                            </div>
                                            <div class="item">
                                              <a href=""> <img src="images/02.png"></a>
                                            </div>

                                            <div class="item">
                                              <a href=""> <img src="images/03.png"></a>
                                            </div>

                                            <div class="item">
                                              <a href=""> <img src="images/04.png"></a>
                                            </div>
                                            <div class="item">
                                              <a href=""> <img src="images/06.png"></a>
                                            </div>

                                            <div class="item">
                                              <a href=""> <img src="images/02.png"></a>
                                            </div>
                                             <div class="item">
                                              <a href=""> <img src="images/03.png"></a>
                                            </div>
                                            <div class="item">
                                              <a href=""> <img src="images/04.png"></a>
                                            </div>
                                        </div>
                              
                                    </div>
                            
                                    <script type="text/javascript">
                                      $('.owl-carousel').owlCarousel({
                                        loop:true,
                                        margin:10,
                                        nav:true,
                                        responsive:{
                                           0:{
                                                                items:2
                                                            },
                                                           576:{
                                                                items:3
                                                            },
                                                            767:{
                                                                items:3
                                                            },
                                                            1000:{
                                                                items:6
                                                            }
                                        }
                                    })
                                    </script>
                                </div>
                    </div>
        
            </div>
        </div>
