<?php

/* @var $this \yii\web\View */
/* @var $content string */

use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use frontend\assets\AppAsset;
use common\widgets\Alert;

AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?= Html::csrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
  
</head>
<body>
<?php $this->beginBody() ?>

        <header> 
                <!-- menut top -->
                <div class="menutop wow bounce">
                    <div class="container">
                    <!-- Login -->
                        <div class="login">
                            <span><i class="fa fa-user"></i></span>
                            <span>
                                <a id="login" onClick="login()">Đăng nhập</a>
                                <span>|</span>
                                <a id="dk" onClick="dk()"> Đăng kí</a>
                            </span>
                        </div>
                    <!-- end login -->
                    <!-- Phone -->
                        <div class="phone">
                                <span><i class="fa fa-phone"></i></span>
                                <span>Hotline:<a href="#">090.225.4648</a></span>
                                <span>Tel:<a href="#">024.6259.1561</a></span>
                        </div>
                        <!-- end Phone -->
                    <!-- email -->
                        <div class="email">
                                <span><i class="fa fa-phone"></i></span>
                                <span>Email:<a href="#">inminhphuthinh@gmail.com</a></span>
                        </div>
                    <!-- end Phone -->
                    <!-- email -->
                        <div class="notification">
                                
                                <span><i class="fas fa-bell"></i></span>
                                <span id="myBtn" onClick="modal()">Báo giá</span>
                                <span id="dathang" onClick="dathang()">/Đặt hàng</span>
                        </div>
                    <!-- end Phone -->
                        <div class="contact-icon">
                            <ul>
                                <li><a href="#"><img src="images/bl.png"></a></li>
                                <li><a href="#"><img src="images/fb.png"></a></li>
                                <li><a href="#"><img src="images/gg.png"></a></li>

                                <li><a href="#"><img src="images/p.png"></a></li>
                                <li><a href="#"><img src="images/yt.png"></a></li>
                                <li><a href="#"><img src="images/in.png"></a></li>
                                <li><a href="#"><img src="images/v.png"></a></li>
                            </ul>
                            
                        </div>
                    <!-- end Phone -->
                        <div class="clear"></div>
                    </div>
                </div>
                <!-- content header -->
                <div class="header-page">
                    <div class="container">
                            <div class="logo">
                                <img src="images/logo.png">
                            </div>
                            <div class="slogan">
                                <p>Dịch vụ thiết kế & in ấn chuyên nghiệp</p>
                                <p>góp phần nâng cao giá trị và tỏa sáng thương hiệu</p>
                            </div>
                            <div class="menu-right">
                                
                                <ul>
                                    <li>
                                        <a href="">
                                            <div><img src="images/tk.png"></div>
                                            <div class="ina-slogan"><span>Giá thành hơp lý</span></div>
                                        </a>
                                    </li>
                            
                            
                            
                                    <li>
                                        <a href="">
                                            <div><img src="images/ian.png"></div>
                                            <div class="ina-slogan"><span>Giá thành hơp lý</span></div>
                                        </a>
                                    </li>
                                    
                                    <li>
                                        <a href="">
                                            <div><img src="images/gts.png"></div>
                                            <div class="ina-slogan"><span>Giá thành hơp lý</span></div>
                                        </a>
                                    </li>
                                
                                    <li>
                                        <a href="">
                                            <div><img src="images/tk.png"></div>
                                            <div class="ina-slogan"><span>Giá thành hơp lý</span></div>
                                        </a>
                                    </li>
                            
                                </ul>
                            </div>
                            
                            
                        </div>
                        
                </div>
                
                <div class="menu-main">
                        <div class="container">
                            <div id="main-nav" class="stellarnav">
                                <ul>
                                    <li><a href="">TRANG CHỦ</a>
                                        <ul>
                                            <li><a href="#">ITEM-1</a>
                                                <ul>
                                                    <li><a href="#">ITEM-1.1</a>
                                                        <ul>
                                                            <li><a href="#">ITEM-2</a>
                                                                <ul>
                                                                    <li><li><a href="#">ITEM-2.1</a></li></li>
                                                                    <li><li><a href="#">ITEM-2.2</a></li></li>
                                                                    <li><li><a href="#">ITEM-2.3</a></li></li>
                                                                </ul>
                                                            </li>
                                                            <li><a href="#">ITEM-2</a></li>
                                                            <li><a href="#">ITEM-2</a></li>
                                                            <li><a href="#">ITEM-2</a></li>
                                                        </ul>
                                                    </li>
                                                    <li><a href="#">ITEM-1.1</a></li>
                                                    <li><a href="#">ITEM-1.1</a></li>
                                                    <li><a href="#">ITEM-1.1</a></li>
                                                    <li><a href="#">ITEM-1.1</a></li>
                                                </ul>
                                            </li>
                                            <li><a href="#">Item</a></li>
                                            <li><a href="#">Item</a></li>
                                            
                                        </ul>
                                    </li>
                                    <li><a href="">VỀ MPT</a></li>
                                    <li><a href="">DỊCH VỤ</a></li>
                                    <li><a href="">NHÃN MÁC</a></li>
                                    <li><a href="">BIỂU MẪU</a></li>
                                    <li><a href="">THIỆP CƯỚI</a></li>
                                    <li><a href="">THƯ VIỆN MẪU</a></li>
                                    <li><a href="">KHUYẾN MẠI</a></li>
                                    <li><a href="">TUYỂN DỤNG</a></li>
                                    <li><a href="">TIN TỨC</a></li>
                                    <li class="lh"><a href="">LIÊN HỆ</a></li>
                                    
                                                

                                    
                                   
                                </ul>
                            </div><!-- .stellar-nav -->
                            <div class="search">
                                <span><a href="" >
                                    <img src="images/s.png"></a>    
                                    <div class="input-search">
                                        <input type="text" name="" placeholder="Nhập thông tin">
                                        <button><i class="fas fa-search"></i></button>
                                    </div>
                                </span> 
                                        <span><a href=""><img src="images/vs.png"></a>  </span> 
                                        <span><a href=""><img src="images/E.png"></a>       </span>     
                                    </div>
                            <div class="clear"></div>
                        </div>
                </div>  
        </header>
        <div class="slide">
            <script src="js/jssor.slider.min.js" type="text/javascript"></script>
    
    
            <div id="jssor_1" style="position:relative;margin:0 auto;top:0px;left:0px;width:1300px;height:500px;overflow:hidden;visibility:hidden;">
                <!-- Loading Screen -->
                    <div data-u="loading" class="jssorl-009-spin" style="position:absolute;top:0px;left:0px;width:100%;height:100%;text-align:center;background-color:rgba(0,0,0,0.7);">
                        <img style="margin-top:-19px;position:relative;top:50%;width:38px;height:38px;" src="../svg/loading/static-svg/spin.svg" />
                    </div>
                    <div data-u="slides" style="cursor:default;position:relative;top:0px;left:0px;width:1300px;height:500px;overflow:hidden;">
                        <div>
                            <img data-u="image" src="images/slide.jpg" />
                        </div>
                        <div>
                            <img data-u="image" src="images/slide.jpg" />
                        </div>
                        
                    </div>
                <!-- Bullet Navigator -->
                    <div data-u="navigator" class="jssorb032" style="position:absolute;bottom:12px;right:12px;" data-autocenter="1" data-scale="0.5" data-scale-bottom="0.75">
                        <div data-u="prototype" class="i" style="width:16px;height:16px;">
                            <svg viewBox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                                <circle class="b" cx="8000" cy="8000" r="5800"></circle>
                            </svg>
                        </div>
                    </div>
                <!-- Arrow Navigator -->
                        <div data-u="arrowleft" class="jssora051" style="width:65px;height:65px;top:0px;left:25px;" data-autocenter="2" data-scale="0.75" data-scale-left="0.75">
                            <svg viewBox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                                <polyline class="a" points="11040,1920 4960,8000 11040,14080 "></polyline>
                            </svg>
                        </div>
                        <div data-u="arrowright" class="jssora051" style="width:65px;height:65px;top:0px;right:25px;" data-autocenter="2" data-scale="0.75" data-scale-right="0.75">
                            <svg viewBox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                                <polyline class="a" points="4960,1920 11040,8000 4960,14080 "></polyline>
                            </svg>
                        </div>
            </div>
    
        </div>
   
        <?= $content ?>


        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-xl-3 col-lg-4 col-md-6 col-12">
                        <div class="logo-f">
                            <img src="images/logo-ft.png">
                        </div>
                        <div class="content">
                            <p>Với nhiều  năm kinh nghiệm trong lĩnh vực thiết kế và in ấn ,cùng với đội ngũ nhân viên chuyên nghiệp,tay nghề cao nhất với máy móc hiện đại sẽ mang đến cho bạn dịch vụ hoàn hảo nhất</p>
                        </div>
                        <div class="list">
                            <ul>
                                
                                    <li><a href="#"><img src="images/bl.png"></a></li>
                                    <li><a href="#"><img src="images/fb.png"></a></li>
                                    <li><a href="#"><img src="images/gg.png"></a></li>

                                    <li><a href="#"><img src="images/p.png"></a></li>
                                    <li><a href="#"><img src="images/yt.png"></a></li>
                                    <li><a href="#"><img src="images/in.png"></a></li>
                                    <li><a href="#"><img src="images/v.png"></a></li>
                            </ul>
                                    
                        </div>
                    </div>


                    <div class="col-xl-3 col-lg-4 col-md-6 col-12">
                        <div class="title-link">
                            <span>LINH LIÊN KẾT</span>
                        </div>
                    
                        <div class="list-lists">
                            <ul>
                                
                                    <li><a href="#"><i class="fas fa-caret-right"></i>Thiết kế in card visit lấy nhanh</a></li>
                                    <li><a href="#"><i class="fas fa-caret-right"></i>Thiết kế in card visit lấy nhanh</a></li>
                                    <li><a href="#"><i class="fas fa-caret-right"></i>Thiết kế in card visit lấy nhanh</a></li>

                                    <li><a href="#"><i class="fas fa-caret-right"></i>Thiết kế in card visit lấy nhanh</a></li>
                                    <li><a href="#"><i class="fas fa-caret-right"></i>Thiết kế in card visit lấy nhanh</a></li>
                                    
                            </ul>
                                    
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-lg-4 col-md-6 col-12">
                        <div class="title-link">
                            <span>CHÍNH SÁCH HƯỚNG DẪN</span>
                        </div>
                    
                        <div class="list-lists">
                            <ul>
                                
                                    <li><a href="#"><i class="fas fa-caret-right"></i>Hướng dẫn đặt hàng</a></li>
                                    <li><a href="#"><i class="fas fa-caret-right"></i>Cách thức thanh toán</a></li>
                                    <li><a href="#"><i class="fas fa-caret-right"></i>Câu hỏi thường gặp</a></li>
                                    <li><a href="#"><i class="fas fa-caret-right"></i>Thỏa thuận sử dụng</a></li>
                                    <li><a href="#"><i class="fas fa-caret-right"></i>Chính sách bảo mật</a></li>
                                    
                            </ul>
                                    
                        </div>
                    </div>

                    <div class="col-xl-3 col-lg-4 col-md-6 col-12">
                        <div class="title-link">
                            <span>GIỜ LÀM VIỆC</span>
                        </div>
                    
                        <div class="list-lists">
                            <ul>
                                
                                    <li><a href="#">Thứ 2- Thứ 6:<span>8h00-17h30</span></a></li>
                                    <li><a href="#">Thứ 7:<span>8h00-12h00</span></a></li>
                                    <li><a href="#">Chủ nhật và ngày lễ:<span>Nghỉ</span></a></li>
                                    

                                    
                                    
                            </ul>
                                    
                        </div>
                    </div>
                    
                    <div class="col-xl-12">
                        <hr>
                        <div class="of">
                            <div class="row">
                                <div class="col-xl-8 col-lg-8 col-md-8 col-12">
                                    <div class="row">
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-12">
                                            <div class="of-1">
                                                 <span><a>HEAD OFFICE 1</a></span>
                                            </div>
                                            <div class="content">
                                                <ul>
                                                    <li><b>Add 1:</b>P212A, Tầng 2 toàn nhà G6B,Thành công,Ba Đình,HN</li>
                                                    <li><b>Tell:</b>0462.591.561</li>
                                                    <li><b>Cell:</b>090.225.4648-0936.145.386</li>
                                                    <li><b>Email:</b>inminhphuthinh@gmail.com</li>
                                                    <li><b>Skype:</b>inminhphuthinh</li>
                                                </ul>
                                            </div>
                                        </div>
                                

                                    <div class="col-xl-6 col-lg-6 col-md-6 col-12">
                                        <div class="of-1">
                                             <span><a>HEAD OFFICE 1</a></span>
                                        </div>
                                        <div class="content">
                                            <ul>
                                                <li><b>Add 1:</b>P212A, Tầng 2 toàn nhà G6B,Thành công,Ba Đình,HN</li>
                                                <li><b>Tell:</b>0462.591.561</li>
                                                <li><b>Cell:</b>090.225.4648-0936.145.386</li>
                                                <li><b>Email:</b>inminhphuthinh@gmail.com</li>
                                                <li><b>Skype:</b>inminhphuthinh</li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div class="col-xl-12 col-lg-12 col-md-12 col-12">
                                        <p>Copyright    &copy; 2017 MPT.All rights reserved -Designed by:Nanoweb</p>
                                    </div>
                                </div>
                            </div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-12">
                                    <a href="#">
                                        <img src="images/ffb.jpg" style="max-width: 100%">
                                    </a>
                                </div>

                            </div>
                        </div>
                        
                    </div>

                </div>
            </div>
        </footer>

<div class="popup">
    <div id="myModal" class="modal">

      <!-- Modal content -->
      <div class="modal-content ">
        <div class="title-modal">
            <span>BÁO GIÁ SẢN PHẨM</span>
             <span class="close">&times;</span>
             <div style="clear: both;"></div>
        </div>
       <div class="form-modal">
            <form>
                
                            <div class="name-ct">
                                <p>Tên công ty</p>
                                <input type="text" name="" placeholder="Nhập tên công ty">
                            </div>
                        
                            <div class="address">
                                <p>Địa chỉ</p>
                                <input type="text" name="" placeholder="Nhập địa chỉ">
                            </div>
                        
                            <div class="names">
                                <p>Tên của bạn<b> *</b></p>
                                <input type="text" name="" placeholder="Nhập tên công ty">
                            </div>
                        
                            <div class="phone">
                                <p>Số điện thoại<b> *</b></p>
                                <input type="text" name="" placeholder="Nhập số điện thoại ">
                            </div>
                        
                            <div class="email">
                                <p>Email<b> *</b></p>
                                <input type="text" name="" placeholder="Nhập tên email">
                            </div>
                        
                            <div class="dv">
                                <p>Chọn dịch vụ<b> *</b></p>
                                <select>
                                    <option>Chọn một dịch vụ</option>
                                </select>
                            </div>
                    
                        
                            <div class="note">
                                <p>Ghi chú thêm</p>
                                <textarea placeholder="Nhập nội dung"></textarea>
                            </div>
                        
                            <div class="sm">
                                <input type="submit" name="" value="Gửi yêu cầu">
                            </div>
                        
                        
                        
                    
            </form>
       </div>
        
      </div>
    </div>

    <div id="mydk" class="modal">

      <!-- Modal content -->
      <div class="modal-content ">
        <div class="title-modal">
            <span>ĐĂNG KÝ</span>
             <span class="close">&times;</span>
             <div style="clear: both;"></div>
        </div>
       <div class="form-modal">
            <form>
                
                            <div class="name-dk">
                                <p>Tên đăng nhập</p>
                                <input type="text" name="" placeholder="Nhập tên đăng nhập">
                            </div>
                        
                            <div class="email-dk">
                                <p>Địa chỉ email</p>
                                <input type="text" name="" placeholder="Nhập địa chỉ email">
                            </div>
                        
                            <div class="matkhau-dk">
                                <p>Nhập mật khẩu</p>
                                <input type="text" name="" placeholder="Nhập tên mật khẩu">
                            </div>
                        
                            <div class="matkhau-dk">
                                <p>Xác nhận mật khẩu</p>
                                <input type="text" name="" placeholder="Nhập lại mật khẩu ">
                            </div>
                        
                            <div class="sm-dk">
                                <input type="submit" name="" value="Gửi yêu cầu">
                            </div>

                            <div class="link-login">
                                <p>Bạn có tài khoản,đăng nhập <a href="">tại đây</a></p>
                            </div>
                        
                        
                        
                    
            </form>
       </div>
        
      </div>
    </div>

    <div id="myLogin" class="modal">

      <!-- Modal content -->
      <div class="modal-content ">
        <div class="title-modal">
            <span>ĐĂNG NHẬP</span>
             <span class="close">&times;</span>
             <div style="clear: both;"></div>
        </div>
       <div class="form-modal">
            <form>
                
                            <div class="name-dn">
                                <p>Tên đăng nhập</p>
                                <input type="text" name="" placeholder="Nhập tên đăng nhập">
                            </div>
                        
                            <div class="email-dn">
                                <p>Mật khẩu</p>
                                <input type="password" name="" placeholder="Nhập địa mật khẩu">
                            </div>
                        
                            
                        
                            <div class="sm-login">
                                <input type="submit" name="" value="Gửi yêu cầu">
                            </div>

                            <div class="link-quen">
                                <p>Quên tài khoản  <a href="">nhấn vào đây</a></p>
                            </div>
                        
                        
                        
                    
            </form>
       </div>
        
      </div>
    </div>

    <div id="mydathang" class="modal">

      <!-- Modal content -->
      <div class="modal-content ">
        <div class="title-modal">
            <span>ĐẶT HÀNG</span>
             <span class="close">&times;</span>
             <div style="clear: both;"></div>
        </div>
       <div class="form-modal">
            <form>
                
                            <div class="name-dh">
                                <p>Tên của bạn <b>*</b></p>
                                <input type="text" name="" placeholder="Nhập tên đăng nhập">
                            </div>
                        
                            <div class="phone-dh">
                                <p>Số điện thoại <b>*</b></p>
                                <input type="text" name="" placeholder="Nhập địa mật khẩu">
                            </div>
                            <div class="email-dh">
                                <p>Email </p>
                                <input type="email" name="" placeholder="Nhập địa mật khẩu">
                            </div>
                            <div class="sp-dh">
                                <p>Chọn sản phẩm <b>*</b></p>
                                <select>
                                    <option>Chọn sản phẩm</option>
                                </select>
                            </div>
                            <div class="qc-sp">
                                <p>Quy cách sản phẩm <b>*</b></p>
                                <textarea placeholder="Nhập nội dung"></textarea>
                            </div>
                        
                            <div class="sm-login">
                                <input type="submit" name="" value="Gửi yêu cầu">
                            </div>

                        
                        
                        
                    
            </form>
       </div>
        
      </div>
    </div>

</div>
   
<?php $this->endBody() ?>

 <script type="text/javascript" src="js/modal.js"></script>


        <script type="text/javascript">
            jssor_1_slider_init = function() {

                var jssor_1_options = {
                  $AutoPlay: 1,
                  $SlideDuration: 800,
                  $SlideEasing: $Jease$.$OutQuint,
                  $ArrowNavigatorOptions: {
                    $Class: $JssorArrowNavigator$
                  },
                  $BulletNavigatorOptions: {
                    $Class: $JssorBulletNavigator$
                  }
                };

                var jssor_1_slider = new $JssorSlider$("jssor_1", jssor_1_options);

                /*#region responsive code begin*/

                var MAX_WIDTH = 3000;

                function ScaleSlider() {
                    var containerElement = jssor_1_slider.$Elmt.parentNode;
                    var containerWidth = containerElement.clientWidth;

                    if (containerWidth) {

                        var expectedWidth = Math.min(MAX_WIDTH || containerWidth, containerWidth);

                        jssor_1_slider.$ScaleWidth(expectedWidth);
                    }
                    else {
                        window.setTimeout(ScaleSlider, 30);
                    }
                }

                ScaleSlider();

                $Jssor$.$AddEvent(window, "load", ScaleSlider);
                $Jssor$.$AddEvent(window, "resize", ScaleSlider);
                $Jssor$.$AddEvent(window, "orientationchange", ScaleSlider);
                /*#endregion responsive code end*/
            };
        </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js"></script>
    <script type="text/javascript">
        new WOW().init();
    </script>
    <script type="text/javascript">jssor_1_slider_init();</script>
    
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            jQuery('.stellarnav').stellarNav({
                theme: 'light'
            });
        });
    </script>
</body>
</html>
<?php $this->endPage() ?>
