function modal(){
	var modal = document.getElementById('myModal');

	// Get the button that opens the modal
	var btn = document.getElementById("myBtn");

	// Get the <span> element that closes the modal
	var span = document.getElementsByClassName("close")[0];

	// When the user clicks the button, open the modal 
	//btn.onclick = function() {
	    modal.style.display = "block";
	//}

	// When the user clicks on <span> (x), close the modal
	span.onclick = function() {
	    modal.style.display = "none";
	}

	// When the user clicks anywhere outside of the modal, close it
	window.onclick = function(event) {
	   if (event.target == dk || event.target == login || event.target == modal) {
	        modal.style.display = "none";
	    }
	}

}
function login(){
		var login = document.getElementById('myLogin');
		// Get the button that opens the modal
		var btn = document.getElementById("login");

		// Get the <span> element that closes the modal
		var span = document.getElementsByClassName("close")[2];

		// When the user clicks the button, open the modal 

		    login.style.display = "block";


		// When the user clicks on <span> (x), close the modal
		span.onclick = function() {
		    login.style.display = "none";
		}

		// When the user clicks anywhere outside of the modal, close it
		window.onclick = function(event) {
		   if (event.target == dk || event.target == login || event.target == modal) {
		        login.style.display = "none";

		    }
		}
	}
	function dk(){
		var dk = document.getElementById('mydk');
		// Get the button that opens the modal
		var btn = document.getElementById("dk");

		// Get the <span> element that closes the modal
		var span = document.getElementsByClassName("close")[1];

		// When the user clicks the button, open the modal 
	
		    dk.style.display = "block";


		// When the user clicks on <span> (x), close the modal
		span.onclick = function() {
		    dk.style.display = "none";
		}

		// When the user clicks anywhere outside of the modal, close it
		window.onclick = function(event) {
		    if (event.target == dk || event.target == login || event.target == modal) {
		        dk.style.display = "none";
		       
		    }
		}
	}
		function dathang(){
		var dathang = document.getElementById('mydathang');
		// Get the button that opens the modal
		var btn = document.getElementById("dk");

		// Get the <span> element that closes the modal
		var span = document.getElementsByClassName("close")[3];

		// When the user clicks the button, open the modal 
	
		    dathang.style.display = "block";


		// When the user clicks on <span> (x), close the modal
		span.onclick = function() {
		    dathang.style.display = "none";
		}

		// When the user clicks anywhere outside of the modal, close it
		window.onclick = function(event) {
		    if (event.target == dathang || event.target == login || event.target == modal) {
		        dathang.style.display = "none";
		       
		    }
		}
	}