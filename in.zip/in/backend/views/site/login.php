<?php

/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model \common\models\LoginForm */

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;

$this->title = 'Login';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-login">

    
       
            <?php $form = ActiveForm::begin(['id' => 'login-form']); ?>

                <?= $form->field($model, 'username')->textInput(['autofocus' => true,"placeholder"=>"username",'id'=>"inputEmail"])->label(false) ?>

                <?= $form->field($model, 'password')->passwordInput(["placeholder"=>"password",'id'=>"inputPassword"])->label(false) ?>

                <div class="form-group">
                    <?= Html::submitButton('Login', ['class' => 'btn btn-lg btn-primary btn-block btn-signin', 'name' => 'login-button']) ?>
                </div>

            <?php ActiveForm::end(); ?>
        
    
</div>
