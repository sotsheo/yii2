<?php

use yii\helpers\Html;
use yii\grid\GridView;
use backend\models\Serviceproduct;
/* @var $this yii\web\View */
/* @var $searchModel backend\models\search\Serviceproduct */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Serviceproducts';
$this->params['breadcrumbs'][] = $this->title;

?>
<div class="serviceproduct-index">
 <div class="content">
    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Create Serviceproduct', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        // 'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            'name',
            [
                    'attribute' => 'id_parent',
                    'format' => 'html',    
                    'value' => function ($data) {
                        $sv=Serviceproduct::find()->all();
                        foreach ($sv as $item) {
                           if($data->id_parent==$item->id){
                              return $item->name;
                           }
                          
                        }
                        return "Khong co";
                        
                    },
                ],
            
            

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
</div>