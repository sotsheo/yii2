<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model backend\models\Serviceproduct */

$this->title = 'Create Serviceproduct';
$this->params['breadcrumbs'][] = ['label' => 'Serviceproducts', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="serviceproduct-create">
<div class="content">
    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
</div>
