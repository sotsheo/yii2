<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use backend\models\Serviceproduct;
/* @var $this yii\web\View */
/* @var $model backend\models\Serviceproduct */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="serviceproduct-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>
	<?php
	        $cat=new Serviceproduct;
	    ?>
	    <?= $form->field($model, 'parent')->dropDownList([
	    	["0"=>'parent'],
	        $cat->getParent()
        	
	    ]) ?>
   

   

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
