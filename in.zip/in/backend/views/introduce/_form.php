<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model backend\models\Introduce */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="introduce-form">
    <div class="content">

        <?php $form = ActiveForm::begin(); ?>

        <?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>

        <div class="row">
            <div class="col-md-6">
                <?= $form->field($model, 'image')->textInput(['id'=>"image"]) ?>
                 <img src='<?php echo $model->image;?>' id="show-img">
                <a href="#" title="Chon hinh anh" class="btn btn-info btn-sm" id="select-img">Chọn ảnh</a>
                <a href="#" title="Chon hinh anh" class="btn btn-info btn-sm" id="remove-img">Xóa ảnh</a>
            </div>
            <div class="col-md-6">
               
            </div>
        </div>

        <?= $form->field($model, 'number')->textInput() ?>

      

        <div class="form-group">
            <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
        </div>

        <?php ActiveForm::end(); ?>

    </div>
</div>