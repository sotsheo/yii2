<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel backend\models\search\Introduce */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Giới thiệu';
$this->params['breadcrumbs'][] = $this->title;
?>

 <section class="content-header">
      <h1>
       <?= Html::encode($this->title) ?>
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Tables</a></li>
        <li class="active">Data tables</li>
      </ol>
    </section>
<div class="introduce-index">

    <div class="content">
        <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

        <p>
            <?= Html::a('Thêm giới thiệu', ['create'], ['class' => 'btn btn-success']) ?>
        </p>

        <?= GridView::widget([
            'dataProvider' => $dataProvider,
            // 'filterModel' => $searchModel,
            'columns' => [
                ['class' => 'yii\grid\SerialColumn'],

                'id',
                'name',
                [
                    'attribute' => 'image',
                    'format' => 'html',    
                    'value' => function ($data) {
                        return Html::img($data->image,
                            ['width' => '70px']);
                    },
                ],

                 [
                    'attribute' => 'number',
                    'format' => 'html',    
                    'value' => function ($data) {
                        return number_format($data->number);
                    },
                ],
                
               
                // 'created_at',
                //'updated_at',

                ['class' => 'yii\grid\ActionColumn'],
            ],
        ]); ?>
    </div>
</div>
