$('a#select-img').click(function(event){

		event.preventDefault();
		$("#modal-images").modal("show");
		$('#modal-images').on('hide.bs.modal',function(e){
			var imgurl=$('input#image').val();
			$('img#show-img').attr('src',imgurl);
		});
	});

	$('a#remove-img').click(function(event){

		event.preventDefault();
		
			$('input#image').val('');
			$('img#show-img').attr('src','');
		
	});