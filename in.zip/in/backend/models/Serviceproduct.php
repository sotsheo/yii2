<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "Serviceproduct".
 *
 * @property int $id
 * @property string $name
 * @property int $id_parent
 * @property int $created_at
 * @property int $updated_at
 */
class Serviceproduct extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    private $_cats=[];
    public static function tableName()
    {
        return 'Serviceproduct';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name', 'created_at', 'updated_at'], 'required'],
            [['id_parent', 'created_at', 'updated_at'], 'integer'],
            [['name'], 'string', 'max' => 255],
            [['name'], 'unique'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'id_parent' => 'Parent',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }
    public function getParent($lv='',$parent=''){
        $data=Serviceproduct::find()->all();
        if($data):
            foreach ($data as $item):
                if($item->id_parent == 0){
                    $this->_cats[$item->id]=$lv.$item->name;
                    $this->_cats[$item->id]=$item->name;
                }
                
            endforeach;
        endif;
        return $this->_cats;
    }
}
